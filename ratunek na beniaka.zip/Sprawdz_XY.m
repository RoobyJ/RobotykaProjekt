function [zmin, zmax] = Sprawdz_XY(X_wprowadzone,Y_wprowadzone)
 
r2=860;
r3=440;
z=492;
 
zmin=z;
zmax=z;

for i=z:(z+r2+r3)
     
    dlugosc=round(sqrt(X_wprowadzone^2+Y_wprowadzone^2+(i-z)^2));
     
    [alpha_obl, theta_obl, phi_obl]=Katy_obl(X_wprowadzone,Y_wprowadzone,i);
     
    if (dlugosc<=r2+r3 && imag(theta_obl)==0 && imag(phi_obl)==0 && i>zmax) zmax=i;   
    end;
 
end;


k8=sqrt(X_wprowadzone*X_wprowadzone + Y_wprowadzone*Y_wprowadzone);
k11 = k8*k8;
 k19=(1300*1300 - (X_wprowadzone*X_wprowadzone + Y_wprowadzone*Y_wprowadzone));
 k10 = sqrt(k19);
 zmax = k10+492;
        for i=z-(r2+r3):z
     
    dlugosc=round(sqrt(X_wprowadzone^2+Y_wprowadzone^2+(i-z)^2));
     
    [alpha_obl, theta_obl, phi_obl]=Katy_obl(X_wprowadzone,Y_wprowadzone,i);
     
   if (dlugosc<=r2+r3 && imag(theta_obl)==0 && imag(phi_obl)==0 && i<zmin) 
        zmin=i;       
        if zmin<52 zmin=52; end;
    end;
         end;
         

          
 k3=748;
 k4=1240;

 k8=sqrt(X_wprowadzone*X_wprowadzone + Y_wprowadzone*Y_wprowadzone); %d�ugosc od �rodka
   k5=492+sqrt(abs((748*748)- (X_wprowadzone*X_wprowadzone + Y_wprowadzone*Y_wprowadzone))); %obliczenie z w ma�ej przestrzeni
   k6 =492-sqrt(440*440 - ((k8-860)^2)); %obliczenie z za ostatni� osi�
      k9 =492-sqrt(440*440 - ((860-k8)^2));% obliczenie z na �uku przed ostatni� osi�
      k20= tan(pi+phi_obl)*(860-k8);
   k7= sqrt(abs(X_wprowadzone)*abs(X_wprowadzone) + abs(Y_wprowadzone)*abs(Y_wprowadzone));
   
   
   zmin1 = k20;
   if((phi_obl<0)&(theta_obl<15)&(theta_obl>0));
        zmin=492-440*sin(abs(phi_obl));
    end;
        
  if ((k7)<643);
     
    zmin = k5;
      end;
 if((k7>860));
     zmin=k6;
 end;
 if(k7<860&k7>642);
     zmin = k9; %na �uku
     

   
end;

 if(abs(X_wprowadzone)==1280); %Dodatkowe warunki
     zmin = i;
 end;
if (k8==1300); %dodatkowe warunki
    zmin = 492;
    zmax = 492;
end;
