function [ymin, ymax] = Sprawdz_x(X_wprowadzone)
 
r2=860;
r3=440;
r_min=1;
 
alfa_max=180;
 
ymin=r2+r3;
ymax=0;
 
for y=0:(r2+r3)
     k10 = sqrt(1300*1300 - X_wprowadzone* X_wprowadzone);
   dlugosc=round(sqrt(X_wprowadzone^2+y^2));
    [alpha_obl, theta_obl, phi_obl]=Katy_obl(X_wprowadzone,y,492);
 
            if (dlugosc>=r_min&&abs(alpha_obl)<=alfa_max&&imag(alpha_obl)==0&&y<ymin) ymin=y;
       
             end;
                if (abs(alpha_obl)<=alfa_max && imag(alpha_obl)==0 && imag(theta_obl)==0 && y>ymax) ymax=y;
                end;
 ymax = k10;
    end;

