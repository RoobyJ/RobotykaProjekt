function [x_obl, y_obl, z_obl] = Punkt_obl(alpha,theta,phi)
    r2=860;
    r3=440;
     
    z=492;
     
    alpha=(alpha*pi/180);
    theta=(theta*pi/180);
    phi=(phi*pi/180);
 
    x1=r2.*cos(theta).*cos(alpha);
    y1=r2.*cos(theta).*sin(alpha);
    z1=r2.*sin(theta);
     
    x2=r3.*cos(theta+phi).*cos(alpha);
    y2=r3.*cos(theta+phi).*sin(alpha);
    z2=r3.*sin(theta+phi);
     
    x_obl=x1+x2;
    y_obl=y1+y2;
    z_obl=z1+z2+z;