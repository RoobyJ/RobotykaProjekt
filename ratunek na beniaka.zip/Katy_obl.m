function [alpha_obl, theta_obl, phi_obl] = Katy_ob(x,y,z)
    r2=860;
    r3=440;
     
    z=z-492;
     
    if (x<0&&y>=0) alpha_obl=pi-asin(y/sqrt(x^2+y^2));
    else
        if (x<0&&y<0) alpha_obl=-pi-asin(y/sqrt(x^2+y^2));
          else alpha_obl=asin(y/sqrt(x^2+y^2));
        end;
    end;
    
     
    if (z<=0) 
        theta_obl=(asin(z/sqrt(x^2+y^2+z^2))+acos((r2^2-r3^2+x^2+y^2+z^2)/(2*r2*sqrt(x^2+y^2+z^2))));
         phi_obl=-abs(pi-acos((r2^2+r3^2-x^2-y^2-z^2)/(2*r2*r3)));
     else
         theta_obl=(asin(z/sqrt(x^2+y^2+z^2))+acos((r2^2-r3^2+x^2+y^2+z^2)/(2*r2*sqrt(x^2+y^2+z^2))));
        phi_obl=-abs(pi-acos((r2^2+r3^2-x^2-y^2-z^2)/(2*r2*r3)));
     end;
     
    phi_obl=-abs(pi-acos((r2^2+r3^2-x^2-y^2-z^2)/(2*r2*r3)));
        
    alpha_obl=alpha_obl*180/pi;
    theta_obl=(theta_obl*180/pi);
    phi_obl=phi_obl*180/pi;