clear all
close all
a3=515;
a2=560;
a1=400;

 vmax=[139,188,363];% vtheta 1 dps/vtheta2 dps/ vtheta3 dps


 %% 
 %wybieramy konfigujacje righty/lefty, sprawdzamy czy?które? są poprawne
fi1_start=input('Podaj wartosc poczatkowa  kata 1 (od -180 do 180): ');%k1
while (fi1_start<(-180) || fi1_start>180)
    disp('Przekroczono zakres ruchu');
    fi1_start=input('Ponownie wprowadz kat 1: ');
end;
fi2_start=input('Podaj wartosc poczatkowa  kata 2 (od -120 do 120): ');%k2
while (fi2_start<(-120) || fi2_start>120)
    disp('Przekroczono zakres ruchu');
    fi2_start=input('Ponownie wprowadz kat 2: ');
end;
fi3_start=input('Podaj wartosc poczatkowa  kata 3 (od -120 do 120): ');%z
while (fi3_start>120 || fi3_start<-120)
    disp('Przekroczono zakres ruchu');
    fi3_start=input('Ponownie wprowadz kat d: ');
end;

  fi1_end=input('Podaj wartosc koncowa  kata 1 (od -180 do 180): ');%k1
while (fi1_end<(-180) || fi1_end>180)
    disp('Przekroczono zakres ruchu');
    fi1_end=input('Ponownie wprowadz kat 1: ');
end;
fi2_end=input('Podaj wartosc koncowa  kata 2 (od -120 do 120): ');%k2
while (fi2_end<(-120) || fi2_end>120)
    disp('Przekroczono zakres ruchu');
    fi2_end=input('Ponownie wprowadz kat 2: ');
end;
fi3_end=input('Podaj wartosc koncowa  kata 3 (od -120 do 120): ');%z
while (fi3_end>120 || fi3_end<-120)
    disp('Przekroczono zakres ruchu');
    fi3_end=input('Ponownie wprowadz kat d: ');
end;
%%
[xe,ye,ze] = prostakin(fi1_end*pi()/180,fi2_end*pi()/180,fi3_end*pi()/180);
[xs,ys,zs] = prostakin(fi1_start*pi()/180,fi2_start*pi()/180,fi3_start*pi()/180);

delta_konfiguracyjne=[fi1_end-fi1_start,fi2_end-fi2_start,fi3_end-fi3_start];
%wyniki
disp(['Katy poczatkowe (Theta1,Theta2,Theta3)=(' num2str(fi1_start),'�,',num2str(fi2_start) ,'�,',num2str(fi3_start),'�)',]);
disp(['Katy koncowe (Theta1,Theta2, Theta3)=(' num2str(fi1_end),'�,',num2str(fi2_end),'�,',num2str(fi3_end),'�)',]);
disp(['roznice katow (delta_Theta1,delta_Theta2,delta_Theta3)=(' num2str(delta_konfiguracyjne(1)) ,',',num2str(delta_konfiguracyjne(2)) ,'�, ',num2str(delta_konfiguracyjne(3)),'�)',]);





%% 


maksymalny_czas_ruchu = abs(delta_konfiguracyjne./vmax);
 
ramp = 0.1;%%PROCENT CZASU RUCHU ROBOTA W KTORYM przyspiesza a!= 0(accel, decel)
v_zlacza=delta_konfiguracyjne./max(maksymalny_czas_ruchu);
time_obl=max(maksymalny_czas_ruchu);
t_accel=ramp*time_obl; %czas rozpedzania
smax=time_obl; %czas ruchu z pelna predkoscia
t_deccel=smax/1-t_accel; %czas rozpoczecia hamowania
%czas dla predkosci i ruchu zlacz
t1=linspace(0,t_accel);
t2=linspace(t_accel*1.01,t_accel+t_deccel); 
t3=linspace((t_accel+t_deccel)*1.01, t_accel*2+t_deccel);
t=[t1 t2 t3];
 
v1_theta1=(v_zlacza(1)/t_accel)*t1;%predkosci w zlaczu theta1
v2_theta1=(v_zlacza(1)*t2)./t2;
v3_theta1=v_zlacza(1)-(v_zlacza(1)/t_accel)*(t3-t_accel-t_deccel);
v_theta1=[v1_theta1 v2_theta1 v3_theta1];
v1_theta2=(v_zlacza(2)/t_accel)*t1;%predkosci w zlaczu theta2
v2_theta2=(v_zlacza(2)*t2)./t2;
v3_theta2=v_zlacza(2)-(v_zlacza(2)/t_accel)*(t3-t_accel-t_deccel);
v_theta2=[v1_theta2 v2_theta2 v3_theta2];
v1_theta3=(v_zlacza(3)/t_accel)*t1;%predkosci w zlaczu przesuwnym
v2_theta3=(v_zlacza(3)*t2)./t2;
v3_theta3=v_zlacza(3)-(v_zlacza(3)/t_accel)*(t3-t_accel-t_deccel);
v_theta3=[v1_theta3 v2_theta3 v3_theta3];
figure(1)%wykres predkosci zlacz w czasie
plot(t,v_theta1,'r',t,v_theta2,'g',t,v_theta3,'b')
title('Wykres predkosci zlaczy');
xlabel('Czas');
ylabel('Predkosc');
legend('Theta1 [�/s]','Theta2 [�/s]','Theta3 [�/s]');
grid;
 
% ruch w złączu theta1
s1_theta1=0.5*(v_zlacza(1)/t_accel)*t1.*t1;
s1t_accel_theta1=0.5*(v_zlacza(1)/t_accel)*t_accel^2;
s2_theta1=s1t_accel_theta1+v_zlacza(1)*(t2-t_accel);
s2t_deccel_theta1=s1t_accel_theta1+v_zlacza(1)*t_deccel;
s3_theta1=s2t_deccel_theta1+v_zlacza(1)*(t3-t_accel-t_deccel)-0.5*(v_zlacza(1)/t_accel)*(t3-t_accel-t_deccel).*(t3-t_accel-t_deccel);
s3t_accel_theta1=s2t_deccel_theta1+v_zlacza(1)*(t_accel)-0.5*(v_zlacza(1)/t_accel)*t_accel^2;

%ruchu w złączu theta2
s1_theta2=0.5*(v_zlacza(2)/t_accel)*t1.*t1;
s1t_accel_theta2=0.5*(v_zlacza(2)/t_accel)*t_accel^2;
s2_theta2=s1t_accel_theta2+v_zlacza(2)*(t2-t_accel);
s2t_deccel_theta2=s1t_accel_theta2+v_zlacza(2)*t_deccel;
s3_theta2=s2t_deccel_theta2+v_zlacza(2)*(t3-t_accel-t_deccel)-0.5*(v_zlacza(2)/t_accel)*(t3-t_accel-t_deccel).*(t3-t_accel-t_deccel);
s3t_accel_theta2=s2t_deccel_theta2+v_zlacza(2)*(t_accel)-0.5*(v_zlacza(2)/t_accel)*t_accel^2;

%ruch w złączu theta 3
s1_theta3=0.5*(v_zlacza(3)/t_accel)*t1.*t1;
s1t_accel_theta3=0.5*(v_zlacza(3)/t_accel)*t_accel^2;
s2_theta3=s1t_accel_theta3+v_zlacza(3)*(t2-t_accel);
s2t_deccel_theta3=s1t_accel_theta3+v_zlacza(3)*t_deccel;
s3_theta3=s2t_deccel_theta3+v_zlacza(3)*(t3-t_accel-t_deccel)-0.5*(v_zlacza(3)/t_accel)*(t3-t_accel-t_deccel).*(t3-t_accel-t_deccel);
s3t_accel_theta3=s2t_deccel_theta3+v_zlacza(3)*(t_accel)-0.5*(v_zlacza(3)/t_accel)*t_accel^2;
s_theta1=[s1_theta1 s2_theta1 s3_theta1];%złącza w czasie t1 t2 t3
s_theta2=[s1_theta2 s2_theta2 s3_theta2];
s_theta3=[s1_theta3 s2_theta3 s3_theta3];
figure(2)
plot(t,s_theta1,'r',t,s_theta2,'g',t,s_theta3,'b')
hold on;
title('Wykresy ruchu w zlaczach');
xlabel('Czas [s]');
ylabel('droga');
legend('Theta1 [�]','Theta2 [�]','Theta3 [�]');
grid;
disp(' ');
disp(['Czas ruchu=' num2str(round(t(300),3)),'s']);
%%
figure(3)
plot3(xs,ys,zs,'*g');
hold on;
plot3(xe,ye,ze,'*r');
hold on;
for fi1=-pi/180*180 : (pi/180)*10 : pi/180*180
    for fi2=-(pi/180)*90 : (pi/180)*30: (pi/180)*90
        for  fi3=-(pi/180)*120 : (pi/180)*30 : (pi/180)*120
          r2=860;
r3=440;
r1=492;

x1=r2.*cos(fi2).*cos(fi1);
y1=r2.*cos(fi2).*sin(fi1);
z1=r2.*sin(fi2);

x2=r3.*cos(fi2+fi3).*cos(fi1);
y2=r3.*cos(fi2+fi3).*sin(fi1);45
z2=r3.*sin(fi2+fi3);

x=x1+x2;
y=y1+y2;
z=z1+z2+r1;

        
            plot3(x,y,z,'.b');            
            hold on;
            grid on;
        end
    end
end
%%
[xacc,yacc,zacc]=prostakin((fi1_start+(0.05*delta_konfiguracyjne(1)))*pi()/180,(fi2_start+(0.05*delta_konfiguracyjne(2)))*pi()/180,(fi3_start+(0.03*delta_konfiguracyjne(3)))*pi()/180);
[xdcc,ydcc,zdcc]=prostakin((fi1_end+(0.05*delta_konfiguracyjne(1)))*pi()/180,(fi2_end+(0.05*delta_konfiguracyjne(2)))*pi()/180,(fi3_end+(0.03*delta_konfiguracyjne(3)))*pi()/180);

 czasproste=0:0.5:20; % chwila t dla rysowania prostej na punktach startu i końca ruchu
odleg=12; % odległość punktu kontrolnego od punktu startowego
if fi3_end>150 || fi3_end>150
    odleg=odleg-3;
end
A=[xs,ys,zs]; % wsp punktu startowego
B=[xacc,yacc,zacc] ;% wsp punktu końca przyspieszania
% wsp punktu początku hamowania
D= [xe,ye,ze]; % wsp punktu końcowego
C=[xdcc,ydcc,zdcc]; 
% wyliczanie współczynników dla prostych 
BminusA=B-A;
DminusC=D-C;
x_prostej1=A(1)+BminusA(1)*czasproste;
y_prostej1=A(2)+BminusA(2)*czasproste;
z_prostej1=A(3)+BminusA(3)*czasproste;
x_prostej2=C(1)+DminusC(1)*czasproste;
y_prostej2=C(2)+DminusC(2)*czasproste;
z_prostej2=C(3)+DminusC(3)*czasproste;
% Przygotowanie punktów do wykreślania prostych i krzywych beziera
%punkty startowe i kontrolne:
P0=[xs ys zs]; %punkt początkowy
P0_a=[x_prostej1(odleg),y_prostej1(odleg),z_prostej1(odleg)]; %punkt kontrolny 1 
P1_b=[x_prostej2(odleg),y_prostej2(odleg),z_prostej2(odleg)]; %punkt kontrolny 2
P1=[xe,ye,ze]; %punkt końcowy
P_krzywa=[P0;P0_a;P1_b;P1].'; % konwersja tablic z punktami na macierz
 
plot3(P_krzywa(1,2),P_krzywa(2,2),P_krzywa(3,2),'kx'); %Wykreślenie punktów kontrolnych
hold on
plot3(P_krzywa(1,3),P_krzywa(2,3),P_krzywa(3,3),'kx'); %Wykreślenie punktów konrolnych
hold on
if t(300)~=0
%Bezier
P=P_krzywa;
 c_x=3*(P(1,2)-P(1,1)); b_x=3*(P(1,3)-P(1,2))-c_x; a_x=P(1,4)-P(1,1)-c_x-b_x;
    c_y=3*(P(2,2)-P(2,1)); b_y=3*(P(2,3)-P(2,2))-c_y; a_y=P(2,4)-P(2,1)-c_y-b_y;
    c_z=3*(P(3,2)-P(3,1)); b_z=3*(P(3,3)-P(3,2))-c_z; a_z=P(3,4)-P(3,1)-c_z-b_z;
    
    % Wyzznaczenie podstawowej funkcji bazowej 0<= t <=1
    % Wyznaczenie współrzędnych
    u=linspace(0,1);
    xt=a_x.*u.^3+b_x.*u.^2+c_x.*u+P(1,1);
    yt=a_y.*u.^3+b_y.*u.^2+c_y.*u+P(2,1);
    zt=a_z.*u.^3+b_z.*u.^2+c_z.*u+P(3,1);
    
    % wyliczenie czasu ruchu na krzywej
    tk=t3(100); %całkowity czas ruchu
    %tj=tk-t_accel; %czas rampy przyspieszania i hamowania
    tj=tk-t_accel;
    inv=400; %ew 400
    sect=1/inv*tk;
    liczba=t_accel/sect;
    u1=floor(liczba);
    if (inv==400) 
        u3=u1+1;
    end
    if (1==1)
        u3=u1+1;  %ew dodać u1+1 w równaniu 
    end
    m2=inv-u1-u3;   %punkty pilnujące ciągłości czasu
    m3=u1+m2; %punkty pilnujące ciągłości czasu
    for u = 0:1:inv
        t=u/inv*tk; 
        if(0<t && t<= t_accel)
            v1x(u) = (c_x+2*b_x*u/inv+3*a_x*(u/inv)^2)/(t_accel/tk)*u/inv;
            v1y(u) = (c_y+2*b_y*u/inv+3*a_y*(u/inv)^2)/(t_accel/tk)*u/inv;
            v1z(u) = (c_z+2*b_z*u/inv+3*a_z*(u/inv)^2)/(t_accel/tk)*u/inv;
            ta(u) = t;
        end
    
        if((t_accel<t) && (t<= tj))
            v2x(u-u1) = (c_x+2*b_x*u/inv+3*a_x*((u/inv)^2));
            v2y(u-u1) = (c_y+2*b_y*u/inv+3*a_y*((u/inv)^2));
            v2z(u-u1) = (c_z+2*b_z*u/inv+3*a_z*((u/inv)^2));
            tb(u-u1) = t;
        end
        if(tj<t && t<=tk)
            v3x(u-m3) = -((c_x+2*b_x*u/inv+3*a_x*(u/inv)^2)/(t_accel/tk))*(u/inv-t_accel/tk-tj/tk);
            v3y(u-m3) = -((c_y+2*b_y*u/inv+3*a_y*(u/inv)^2)/(t_accel/tk))*(u/inv-t_accel/tk-tj/tk);
            v3z(u-m3) = -((c_z+2*b_z*u/inv+3*a_z*(u/inv)^2)/(t_accel/tk))*(u/inv-t_accel/tk-tj/tk);
            tc(u-m3) = t;
        end
    end   
    TXYZ=[ta tb tc];  %macierz wyliczonego czasu
    VX=[v1x v2x v3x]; %macierz prędkości po X
    VY=[v1y v2y v3y]; %macierz prędkości po Y
    VZ=[v1z v2z v3z]; %macierz prędkości po Z
    vv1=sqrt(v1x.^2+v1y.^2+v1z.^2); 
    vv2=sqrt(v2x.^2+v2y.^2+v2z.^2);
    vv3=sqrt(v3x.^2+v3y.^2+v3z.^2);
    VV=[vv1 vv2 vv3]; %macierz sumaryczna prędkości
    PR1=[xt;yt;zt]; %gotowe punkty do wykreślenia krzywej
    plot3(PR1(1,:),PR1(2,:),PR1(3,:),'m','LineWidth',2), % rysowanie krzywej Béziera
end
    kx=VX./VV; % współcznnik v_bezier po X 
    ky=VY./VV; % współcznnik v_bezier po Y
    kz=VZ./VV; % współcznnik v_bezier po Z
%%
    figure(4)
     plot(kx,'r');
    hold on;
    plot(ky,'g');
    hold on;
    plot(kz,'b');
    legend('kx', 'ky', 'kz');
     title({'Wykres wspolczynnikow predkosci'});
    figure(5)
czas_calkowity=linspace(0,t3(100));
    plot(czas_calkowity,PR1(1,:),'r');
    hold on;
    plot(czas_calkowity,PR1(2,:),'g');
    hold on
    plot(czas_calkowity,PR1(3,:),'b');
    hold on
    legend('Sx','Sy','Sz');
    title({'Wykres po�ozen koncowki'});
    figure(6)
    plot(TXYZ,VX,'r')
    xlabel('czas [s]');
    ylabel('VX [mm/s]');
    hold on;
    subplot(1,1,1);
    plot(TXYZ,VY,'g')
    xlabel('czas [s]');
    ylabel('VY [mm/s]');
    hold on;
    subplot(1,1,1);
    plot(TXYZ,VZ,'b')
    xlabel('czas [s]');
    ylabel('VZ [mm/s]');
    hold on;
    subplot(1,1,1);
    plot(TXYZ,VV,'k')
    xlabel('czas [s]');
    ylabel('Predkosc [mm/s]');
    hold on;
     title({'Wykres predkosci koncowki'});
    legend('Vx','Vy','Vz','Vwypadkowa');
    grid on;




 