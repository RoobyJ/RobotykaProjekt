function [zminL, zmaxL] = Sprawdz_XYL(X_wprowadzoneL,Y_wprowadzoneL)

zmaxL=492; %sprawdzianie z na �uku
zminL=492;

k90=(X_wprowadzoneL*X_wprowadzoneL + Y_wprowadzoneL*Y_wprowadzoneL);


k91=sqrt(X_wprowadzoneL*X_wprowadzoneL + Y_wprowadzoneL*Y_wprowadzoneL);
k100=abs((748*748) - (k91*k91));
k101 = sqrt (k100);
if (k91 <748 & k91>642);

k102 = 492 -  k101 ;
zminL = k102;


k103 = 492 +  k101 ;
zmaxL = k103;
end;